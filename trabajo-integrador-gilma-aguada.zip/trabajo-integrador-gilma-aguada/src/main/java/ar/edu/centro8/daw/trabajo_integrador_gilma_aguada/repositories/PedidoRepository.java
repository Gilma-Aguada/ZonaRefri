package ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.repositories;

import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.Pedido;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    
    // Query method 1: Buscar pedidos por cliente
    List<Pedido> findByCliente(Cliente cliente);
    
    // Query method 2: Buscar pedidos por estado de pago
    List<Pedido> findByEstadoPago(String estadoPago);
    
    // Query method adicional: Buscar pedidos por rango de fechas
    List<Pedido> findByFechaBetween(LocalDateTime fechaInicio, LocalDateTime fechaFin);
    
    // Query personalizada: Pedidos pendientes de pago
    @Query("SELECT p FROM Pedido p WHERE p.estadoPago = 'Pendiente' ORDER BY p.fecha DESC")
    List<Pedido> findPedidosPendientes();
    
    // Query personalizada: Pedidos por cliente ID
    @Query("SELECT p FROM Pedido p WHERE p.cliente.idCliente = :clienteId ORDER BY p.fecha DESC")
    List<Pedido> findPedidosByClienteId(@Param("clienteId") Long clienteId);
}

package ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.repositories;

import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    // Query method 1: Buscar clientes por nombre (búsqueda parcial)
    List<Cliente> findByNombreContainingIgnoreCase(String nombre);

    // Query method 2: Buscar cliente por email (validación de unicidad)
    Optional<Cliente> findByEmail(String email);

    // Query method adicional: Buscar cliente por teléfono
    Optional<Cliente> findByTelefono(String telefono);
}
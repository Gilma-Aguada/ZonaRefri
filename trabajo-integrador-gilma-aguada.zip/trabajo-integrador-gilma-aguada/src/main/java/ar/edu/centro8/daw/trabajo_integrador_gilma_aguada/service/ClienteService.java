package ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.service;

import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.Cliente;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.repositories.ClienteRepository;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.exception.ResourceNotFoundException;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.exception.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ClienteService {
    
    @Autowired
    private ClienteRepository clienteRepository;
    
    // CRUD básico
    public List<Cliente> obtenerTodos() {
        return clienteRepository.findAll();
    }
    
    public Cliente obtenerPorId(Long id) {
        return clienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id: " + id));
    }
    
    // Regla de negocio 1: Validar email único antes de crear
    public Cliente crear(Cliente cliente) {
        // Validar que el email no esté registrado
        Optional<Cliente> existente = clienteRepository.findByEmail(cliente.getEmail());
        if (existente.isPresent()) {
            throw new BusinessException("Ya existe un cliente registrado con el email: " + cliente.getEmail());
        }
        
        // Validar formato de teléfono
        if (cliente.getTelefono() == null || cliente.getTelefono().trim().isEmpty()) {
            throw new BusinessException("El teléfono es obligatorio");
        }
        
        // Validar nombre
        if (cliente.getNombre() == null || cliente.getNombre().trim().isEmpty()) {
            throw new BusinessException("El nombre es obligatorio");
        }
        
        return clienteRepository.save(cliente);
    }
    
    // Regla de negocio 2: Validar que el email siga siendo único al actualizar
    public Cliente actualizar(Long id, Cliente clienteActualizado) {
        Cliente clienteExistente = obtenerPorId(id);
        
        // Validar que el email no esté usado por otro cliente
        if (!clienteExistente.getEmail().equals(clienteActualizado.getEmail())) {
            Optional<Cliente> clienteConMismoEmail = clienteRepository.findByEmail(clienteActualizado.getEmail());
            if (clienteConMismoEmail.isPresent() && !clienteConMismoEmail.get().getIdCliente().equals(id)) {
                throw new BusinessException("El email ya está registrado por otro cliente");
            }
        }
        
        clienteExistente.setNombre(clienteActualizado.getNombre());
        clienteExistente.setEmail(clienteActualizado.getEmail());
        clienteExistente.setTelefono(clienteActualizado.getTelefono());
        
        return clienteRepository.save(clienteExistente);
    }
    
    public void eliminar(Long id) {
        Cliente cliente = obtenerPorId(id);
        clienteRepository.delete(cliente);
    }
    
    // Métodos de búsqueda
    public List<Cliente> buscarPorNombre(String nombre) {
        return clienteRepository.findByNombreContainingIgnoreCase(nombre);
    }
    
    public Optional<Cliente> buscarPorEmail(String email) {
        return clienteRepository.findByEmail(email);
    }
}

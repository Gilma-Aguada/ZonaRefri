package ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.repositories;

import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.PedidoDetalle;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.PedidoDetalleId;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.Pedido;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PedidoDetalleRepository extends JpaRepository<PedidoDetalle, PedidoDetalleId> {
    
    // Query method 1: Buscar detalles por pedido
    List<PedidoDetalle> findByPedido(Pedido pedido);
    
    // Query method 2: Buscar detalles por producto
    List<PedidoDetalle> findByProducto(Producto producto);
    
    // Query personalizada: Calcular total de un pedido
    @Query("SELECT SUM(pd.cantidad * pd.precioUnitario) FROM PedidoDetalle pd WHERE pd.pedido.idPedido = :pedidoId")
    Double calcularTotalPedido(@Param("pedidoId") Long pedidoId);
}

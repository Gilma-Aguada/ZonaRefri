package ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.service;

import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.Pedido;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.PedidoDetalle;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.Cliente;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model.Producto;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.repositories.PedidoDetalleRepository;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.repositories.PedidoRepository;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.exception.ResourceNotFoundException;
import ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.exception.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class PedidoService {
    
    @Autowired
    private PedidoRepository pedidoRepository;
    
    @Autowired
    private PedidoDetalleRepository pedidoDetalleRepository;
    
    @Autowired
    private ProductoService productoService;
    
    @Autowired
    private ClienteService clienteService;
    
    // CRUD básico
    public List<Pedido> obtenerTodos() {
        return pedidoRepository.findAll();
    }
    
    public Pedido obtenerPorId(Long id) {
        return pedidoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pedido no encontrado con id: " + id));
    }
    
    // Regla de negocio 1: Crear pedido validando stock de productos
    public Pedido crear(Pedido pedido) {
        // Validar que el cliente exista
        if (pedido.getCliente() == null || pedido.getCliente().getIdCliente() == null) {
            throw new BusinessException("Debe especificar un cliente para el pedido");
        }
        
        Cliente cliente = clienteService.obtenerPorId(pedido.getCliente().getIdCliente());
        pedido.setCliente(cliente);
        
        // Establecer fecha actual si no se especifica
        if (pedido.getFecha() == null) {
            pedido.setFecha(LocalDateTime.now());
        }
        
        // Establecer estado por defecto
        if (pedido.getEstadoPago() == null || pedido.getEstadoPago().trim().isEmpty()) {
            pedido.setEstadoPago("Pendiente");
        }
        
        // Validar dirección de envío
        if (pedido.getDireccionEnvio() == null || pedido.getDireccionEnvio().trim().isEmpty()) {
            throw new BusinessException("La dirección de envío es obligatoria");
        }
        
        // Guardar el pedido
        Pedido pedidoGuardado = pedidoRepository.save(pedido);
        
        // Procesar detalles del pedido
        if (pedido.getDetalles() != null && !pedido.getDetalles().isEmpty()) {
            for (PedidoDetalle detalle : pedido.getDetalles()) {
                agregarDetalle(pedidoGuardado.getIdPedido(), detalle);
            }
        }
        
        return obtenerPorId(pedidoGuardado.getIdPedido());
    }
    
    // Regla de negocio 2: Agregar producto al pedido verificando stock
    public PedidoDetalle agregarDetalle(Long pedidoId, PedidoDetalle detalle) {
        Pedido pedido = obtenerPorId(pedidoId);
        
        // Validar que el producto exista
        if (detalle.getProducto() == null || detalle.getProducto().getIdProducto() == null) {
            throw new BusinessException("Debe especificar un producto válido");
        }
        
        Producto producto = productoService.obtenerPorId(detalle.getProducto().getIdProducto());
        
        // Verificar disponibilidad de stock
        if (!productoService.verificarDisponibilidad(producto.getIdProducto(), detalle.getCantidad())) {
            throw new BusinessException("Stock insuficiente para el producto: " + producto.getNombre());
        }
        
        // Establecer precio unitario actual del producto si no se especifica
        if (detalle.getPrecioUnitario() == null) {
            detalle.setPrecioUnitario(producto.getPrecio());
        }
        
        detalle.setPedido(pedido);
        detalle.setProducto(producto);
        
        // Reducir stock del producto
        productoService.reducirStock(producto.getIdProducto(), detalle.getCantidad());
        
        return pedidoDetalleRepository.save(detalle);
    }
    
    // Regla de negocio 3: Actualizar estado de pago
    public Pedido actualizarEstadoPago(Long id, String nuevoEstado) {
        Pedido pedido = obtenerPorId(id);
        
        // Validar estados permitidos
        List<String> estadosPermitidos = List.of("Pendiente", "Pagado", "Cancelado");
        if (!estadosPermitidos.contains(nuevoEstado)) {
            throw new BusinessException("Estado de pago no válido. Valores permitidos: " + estadosPermitidos);
        }
        
        pedido.setEstadoPago(nuevoEstado);
        return pedidoRepository.save(pedido);
    }
    
    public Pedido actualizar(Long id, Pedido pedidoActualizado) {
        Pedido pedidoExistente = obtenerPorId(id);
        
        pedidoExistente.setDireccionEnvio(pedidoActualizado.getDireccionEnvio());
        pedidoExistente.setEstadoPago(pedidoActualizado.getEstadoPago());
        
        return pedidoRepository.save(pedidoExistente);
    }
    
    public void eliminar(Long id) {
        Pedido pedido = obtenerPorId(id);
        pedidoRepository.delete(pedido);
    }
    
    // Métodos de búsqueda
    public List<Pedido> obtenerPorCliente(Long clienteId) {
        return pedidoRepository.findPedidosByClienteId(clienteId);
    }
    
    public List<Pedido> obtenerPorEstado(String estado) {
        return pedidoRepository.findByEstadoPago(estado);
    }
    
    public List<Pedido> obtenerPendientes() {
        return pedidoRepository.findPedidosPendientes();
    }
    
    // Calcular total del pedido
    public Double calcularTotal(Long pedidoId) {
        Double total = pedidoDetalleRepository.calcularTotalPedido(pedidoId);
        return total != null ? total : 0.0;
    }
}

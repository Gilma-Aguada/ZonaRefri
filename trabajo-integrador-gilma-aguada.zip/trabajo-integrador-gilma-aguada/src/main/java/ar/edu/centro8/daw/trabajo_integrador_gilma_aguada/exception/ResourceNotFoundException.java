// src/main/java/ar/edu/centro8/daw/trabajo_integrador_gilma_aguada/exception/ResourceNotFoundException.java
package ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
